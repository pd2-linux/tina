
void calcLoad(void);
double getCpuLoad(void);
int getCpuNum();
