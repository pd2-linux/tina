""" Config file for 'default' profile """

# get various stuff that are there for historical / familiarity reasons
import ipy_legacy